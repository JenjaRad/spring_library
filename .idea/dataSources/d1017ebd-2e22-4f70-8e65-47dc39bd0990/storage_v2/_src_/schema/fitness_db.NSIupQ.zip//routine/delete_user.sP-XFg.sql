create
  definer = super@`%` procedure delete_user(IN login33 varchar(40))
BEGIN
DELETE FROM users  WHERE login = login33;
END;

