create
  definer = super@`%` procedure update_training(IN begin_training datetime, IN end_training datetime,
                                                IN kind_of_sport varchar(50), IN id_coach int)
BEGIN
UPDATE  coach_par set begin_training =begin_training,end_training=end_training,kind_of_sport=kind_of_sport where id=id;
END;

