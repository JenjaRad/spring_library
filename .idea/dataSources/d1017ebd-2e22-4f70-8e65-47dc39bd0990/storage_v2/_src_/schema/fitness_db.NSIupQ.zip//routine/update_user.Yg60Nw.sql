create
  definer = super@`%` procedure update_user(IN name varchar(30), IN surname varchar(30), IN email varchar(50),
                                            IN number_of_phone varchar(25), IN login varchar(40),
                                            IN password varchar(16), IN type_of_user varchar(10))
BEGIN
UPDATE users set name=name,surname=surname,email=email,
	number_of_phone=number_of_phone,login=login,password=password,type_of_user=type_of_user where id=id;
END;

