create
  definer = super@`%` procedure search_user(IN name varchar(30))
BEGIN

SELECT * from users as qwe where qwe.name  like concat('%',trim(name),'%');
END;

