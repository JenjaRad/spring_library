create
  definer = super@`%` procedure create_user(IN name varchar(30), IN surname varchar(30), IN email varchar(50),
                                            IN number_of_phone varchar(25), IN login varchar(40),
                                            IN password varchar(16), IN type_of_user varchar(10))
BEGIN
INSERT INTO User ( name, surname, email,number_of_phone,
                     login, password, type_of_user) values (name,surname,email,number_of_phone,login,password,type_of_user);
END;

