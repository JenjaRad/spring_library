create
  definer = super@`%` procedure create_training(IN begin_training datetime, IN end_training datetime,
                                                IN kind_of_sport varchar(50), IN id_coach int)
BEGIN
INSERT INTO coach_par( begin_training, end_training, kind_of_sport,id_coach) values (begin_training,end_training,kind_of_sport,id_coach);
END;

