create
  definer = super@`%` procedure delete_training(IN id_train int)
BEGIN
DELETE FROM customer_record WHERE id_training=id_train;
END;

