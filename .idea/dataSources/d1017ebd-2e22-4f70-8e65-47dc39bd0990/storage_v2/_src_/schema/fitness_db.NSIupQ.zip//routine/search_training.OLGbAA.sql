create
  definer = super@`%` procedure search_training(IN surname varchar(30), IN kind_of_sport varchar(50))
BEGIN
declare var varchar(250);
 SET var = CONCAT('SELECT * from users as qwe where ','qwe.surname  like concat('%',trim(surname),'%')');    
    PREPARE stmt FROM @var;
    EXECUTE stmt;
END;

